#pragma once
#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include "accounts.h"
using namespace std;

/*
struct Account //��������� ���������
{
	string login;
	string password;
	int role;
	int money;
};
vector<Account> getVectorAccounts(vector<Account> a);
void saveAccounts(vector<Account> v2);

const string accInfo = "Accounts.txt";
vector<Account> getVectorAccounts(vector<Account> a)
{
	ifstream fin(accInfo, ios::in);
	if (fin.is_open())
	{
		Account temp;
		while (!fin.eof())
		{
			fin >> temp.login
				>> temp.password
				>> temp.role
				>> temp.money;
			a.push_back(temp);
		}
		fin.close();
	}
	else
	{
		cout << "Fatal eror!" << endl;
	}
	return a;
}
void saveAccounts(vector<Account> v2)
{
	ofstream fout(accInfo, ios::out);
	for (int i = 0; i < v2.size(); i++)
	{
		if (i != 0) fout << endl;
		fout << v2.at(i).login
			<< " " << v2.at(i).password
			<< " " << v2.at(i).role
			<< " " << v2.at(i).money;
	}
	fout.close();
}*/