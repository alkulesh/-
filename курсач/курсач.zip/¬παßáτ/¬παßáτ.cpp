﻿#include <iostream>
#include <fstream>
#include <conio.h>
#include <vector>
#include <Windows.h>
#include "structure.h"
#include "accounts.h"


using namespace std;

int main() {
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	vector <Account> v1 = getVectorAccounts(v1);
	inAccount(v1);


}